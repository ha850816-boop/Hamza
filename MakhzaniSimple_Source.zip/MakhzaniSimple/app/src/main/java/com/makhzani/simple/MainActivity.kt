package com.makhzani.simple

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Base64

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var backupJson: String? = null
    private val saveRequest = 401
    private val openRequest = 402

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = false
        web.settings.allowContentAccess = true
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(BackupBridge(), "NativeBackup")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class BackupBridge {
        @JavascriptInterface fun saveBackup(json: String) {
            backupJson = json
            runOnUiThread {
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                    putExtra(Intent.EXTRA_TITLE, "makhzani-backup.json")
                }
                startActivityForResult(intent, saveRequest)
            }
        }
        @JavascriptInterface fun restoreBackup() {
            runOnUiThread {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                }
                startActivityForResult(intent, openRequest)
            }
        }
    }

    @Deprecated("Legacy result handling for document picker")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        val uri = data.data!!
        try {
            if (requestCode == saveRequest) {
                contentResolver.openOutputStream(uri)?.use { it.write((backupJson ?: "").toByteArray(Charsets.UTF_8)) }
                Toast.makeText(this, "تم حفظ النسخة الاحتياطية", Toast.LENGTH_LONG).show()
                backupJson = null
            } else if (requestCode == openRequest) {
                val json = contentResolver.openInputStream(uri)?.use { input -> BufferedReader(InputStreamReader(input, Charsets.UTF_8)).readText() } ?: ""
                val base64 = Base64.getEncoder().encodeToString(json.toByteArray(Charsets.UTF_8))
                web.evaluateJavascript("window.restoreBackupBase64('$base64')", null)
            }
        } catch (e: Exception) {
            Toast.makeText(this, "تعذر إتمام العملية", Toast.LENGTH_LONG).show()
        }
    }
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
